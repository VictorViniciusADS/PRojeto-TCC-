﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Botão para Abrir a tela Ordem de Serviço
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Botão para Abrir a tela Clientes

            Clientes cliente = new Clientes();
            cliente.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Botão para Abrir a tela Fornecedores
            Fornecedores fornecedor = new Fornecedores();
            fornecedor.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Botão para Abrir a tela Fornecedores
            Produtos produto = new Produtos();
            produto.Show();
        }
    }
}

