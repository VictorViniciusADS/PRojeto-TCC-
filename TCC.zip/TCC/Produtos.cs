﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC
{
    public partial class Produtos: Form
    {
        public Produtos()
        {
            InitializeComponent();
        }
                
        private void PnlCadastroProd_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxPç_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnCadastroProd_Click(object sender, EventArgs e)
        {
            PnlCadastroProd.Show();
        }

        private void Produtos_Load(object sender, EventArgs e)
        {
            PnlCadastroProd.Hide();
        }

        private void labe_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliente não encontrado");
        }
    }
}
