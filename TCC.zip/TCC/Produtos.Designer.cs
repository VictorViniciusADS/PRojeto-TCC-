﻿namespace TCC
{
    partial class Produtos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PnlCadastroProd = new System.Windows.Forms.Panel();
            this.BtnCadastroProd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labe = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtDescProd = new System.Windows.Forms.TextBox();
            this.TxtIDProd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtQtdProd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxPç = new System.Windows.Forms.ComboBox();
            this.BtnSalvaProd = new System.Windows.Forms.Button();
            this.BtnAtualizaProd = new System.Windows.Forms.Button();
            this.BtnDelProd = new System.Windows.Forms.Button();
            this.PnlCadastroProd.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(908, 504);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Produtos";
            // 
            // PnlCadastroProd
            // 
            this.PnlCadastroProd.Controls.Add(this.BtnDelProd);
            this.PnlCadastroProd.Controls.Add(this.BtnAtualizaProd);
            this.PnlCadastroProd.Controls.Add(this.BtnSalvaProd);
            this.PnlCadastroProd.Controls.Add(this.comboBoxPç);
            this.PnlCadastroProd.Controls.Add(this.label4);
            this.PnlCadastroProd.Controls.Add(this.TxtQtdProd);
            this.PnlCadastroProd.Controls.Add(this.label3);
            this.PnlCadastroProd.Controls.Add(this.TxtIDProd);
            this.PnlCadastroProd.Controls.Add(this.TxtDescProd);
            this.PnlCadastroProd.Controls.Add(this.label2);
            this.PnlCadastroProd.Controls.Add(this.labe);
            this.PnlCadastroProd.Location = new System.Drawing.Point(230, 31);
            this.PnlCadastroProd.Name = "PnlCadastroProd";
            this.PnlCadastroProd.Size = new System.Drawing.Size(711, 453);
            this.PnlCadastroProd.TabIndex = 1;
            this.PnlCadastroProd.Paint += new System.Windows.Forms.PaintEventHandler(this.PnlCadastroProd_Paint);
            // 
            // BtnCadastroProd
            // 
            this.BtnCadastroProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCadastroProd.Location = new System.Drawing.Point(50, 80);
            this.BtnCadastroProd.Name = "BtnCadastroProd";
            this.BtnCadastroProd.Size = new System.Drawing.Size(117, 44);
            this.BtnCadastroProd.TabIndex = 4;
            this.BtnCadastroProd.Text = "Cadastro";
            this.BtnCadastroProd.UseVisualStyleBackColor = true;
            this.BtnCadastroProd.Click += new System.EventHandler(this.BtnCadastroProd_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(50, 191);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 57);
            this.button1.TabIndex = 5;
            this.button1.Text = "Buscar\r\nProduto";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labe
            // 
            this.labe.AutoSize = true;
            this.labe.Location = new System.Drawing.Point(40, 101);
            this.labe.Name = "labe";
            this.labe.Size = new System.Drawing.Size(58, 13);
            this.labe.TabIndex = 0;
            this.labe.Text = "Descrição:";
            this.labe.Click += new System.EventHandler(this.labe_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID do Produto:";
            // 
            // TxtDescProd
            // 
            this.TxtDescProd.Location = new System.Drawing.Point(126, 94);
            this.TxtDescProd.Name = "TxtDescProd";
            this.TxtDescProd.Size = new System.Drawing.Size(482, 20);
            this.TxtDescProd.TabIndex = 2;
            // 
            // TxtIDProd
            // 
            this.TxtIDProd.Location = new System.Drawing.Point(126, 49);
            this.TxtIDProd.Name = "TxtIDProd";
            this.TxtIDProd.Size = new System.Drawing.Size(63, 20);
            this.TxtIDProd.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Quantidade:";
            // 
            // TxtQtdProd
            // 
            this.TxtQtdProd.Location = new System.Drawing.Point(126, 151);
            this.TxtQtdProd.Name = "TxtQtdProd";
            this.TxtQtdProd.Size = new System.Drawing.Size(124, 20);
            this.TxtQtdProd.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(357, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tipo de Peça:";
            // 
            // comboBoxPç
            // 
            this.comboBoxPç.FormattingEnabled = true;
            this.comboBoxPç.Items.AddRange(new object[] {
            "PÇ",
            "GALÃO",
            "SERVIÇO"});
            this.comboBoxPç.Location = new System.Drawing.Point(461, 157);
            this.comboBoxPç.Name = "comboBoxPç";
            this.comboBoxPç.Size = new System.Drawing.Size(121, 21);
            this.comboBoxPç.TabIndex = 7;
            this.comboBoxPç.SelectedIndexChanged += new System.EventHandler(this.comboBoxPç_SelectedIndexChanged);
            // 
            // BtnSalvaProd
            // 
            this.BtnSalvaProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalvaProd.Location = new System.Drawing.Point(126, 380);
            this.BtnSalvaProd.Name = "BtnSalvaProd";
            this.BtnSalvaProd.Size = new System.Drawing.Size(106, 32);
            this.BtnSalvaProd.TabIndex = 19;
            this.BtnSalvaProd.Text = "Salvar";
            this.BtnSalvaProd.UseVisualStyleBackColor = true;
            // 
            // BtnAtualizaProd
            // 
            this.BtnAtualizaProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAtualizaProd.Location = new System.Drawing.Point(298, 380);
            this.BtnAtualizaProd.Name = "BtnAtualizaProd";
            this.BtnAtualizaProd.Size = new System.Drawing.Size(106, 32);
            this.BtnAtualizaProd.TabIndex = 20;
            this.BtnAtualizaProd.Text = "Atualizar";
            this.BtnAtualizaProd.UseVisualStyleBackColor = true;
            // 
            // BtnDelProd
            // 
            this.BtnDelProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelProd.Location = new System.Drawing.Point(461, 380);
            this.BtnDelProd.Name = "BtnDelProd";
            this.BtnDelProd.Size = new System.Drawing.Size(106, 32);
            this.BtnDelProd.TabIndex = 21;
            this.BtnDelProd.Text = "Excluir";
            this.BtnDelProd.UseVisualStyleBackColor = true;
            // 
            // Produtos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 526);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnCadastroProd);
            this.Controls.Add(this.PnlCadastroProd);
            this.Controls.Add(this.label1);
            this.Name = "Produtos";
            this.Text = "Produtos";
            this.Load += new System.EventHandler(this.Produtos_Load);
            this.PnlCadastroProd.ResumeLayout(false);
            this.PnlCadastroProd.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel PnlCadastroProd;
        private System.Windows.Forms.Button BtnCadastroProd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TxtDescProd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtIDProd;
        private System.Windows.Forms.ComboBox comboBoxPç;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtQtdProd;
        private System.Windows.Forms.Button BtnDelProd;
        private System.Windows.Forms.Button BtnAtualizaProd;
        private System.Windows.Forms.Button BtnSalvaProd;
    }
}