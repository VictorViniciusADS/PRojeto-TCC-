﻿namespace TCC
{
    partial class Fornecedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PnlFornecedor = new System.Windows.Forms.Panel();
            this.BtnCadastroForn = new System.Windows.Forms.Button();
            this.BtnBuscaForn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtCNPJ = new System.Windows.Forms.MaskedTextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BtnSalvaFornecedor = new System.Windows.Forms.Button();
            this.BtnAtualizaForn = new System.Windows.Forms.Button();
            this.BtnExcluiForn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.PnlFornecedor.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(893, 542);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fornecedor";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // PnlFornecedor
            // 
            this.PnlFornecedor.Controls.Add(this.textBox3);
            this.PnlFornecedor.Controls.Add(this.label7);
            this.PnlFornecedor.Controls.Add(this.BtnExcluiForn);
            this.PnlFornecedor.Controls.Add(this.BtnAtualizaForn);
            this.PnlFornecedor.Controls.Add(this.BtnSalvaFornecedor);
            this.PnlFornecedor.Controls.Add(this.label6);
            this.PnlFornecedor.Controls.Add(this.textBox2);
            this.PnlFornecedor.Controls.Add(this.maskedTextBox1);
            this.PnlFornecedor.Controls.Add(this.label5);
            this.PnlFornecedor.Controls.Add(this.label4);
            this.PnlFornecedor.Controls.Add(this.comboBox1);
            this.PnlFornecedor.Controls.Add(this.TxtCNPJ);
            this.PnlFornecedor.Controls.Add(this.label3);
            this.PnlFornecedor.Controls.Add(this.textBox1);
            this.PnlFornecedor.Controls.Add(this.label2);
            this.PnlFornecedor.Location = new System.Drawing.Point(191, 30);
            this.PnlFornecedor.Name = "PnlFornecedor";
            this.PnlFornecedor.Size = new System.Drawing.Size(747, 486);
            this.PnlFornecedor.TabIndex = 1;
            // 
            // BtnCadastroForn
            // 
            this.BtnCadastroForn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCadastroForn.Location = new System.Drawing.Point(33, 81);
            this.BtnCadastroForn.Name = "BtnCadastroForn";
            this.BtnCadastroForn.Size = new System.Drawing.Size(117, 44);
            this.BtnCadastroForn.TabIndex = 4;
            this.BtnCadastroForn.Text = "Cadastro";
            this.BtnCadastroForn.UseVisualStyleBackColor = true;
            this.BtnCadastroForn.Click += new System.EventHandler(this.BtnCadastroForn_Click);
            // 
            // BtnBuscaForn
            // 
            this.BtnBuscaForn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBuscaForn.Location = new System.Drawing.Point(33, 189);
            this.BtnBuscaForn.Name = "BtnBuscaForn";
            this.BtnBuscaForn.Size = new System.Drawing.Size(117, 44);
            this.BtnBuscaForn.TabIndex = 5;
            this.BtnBuscaForn.Text = "Buscar";
            this.BtnBuscaForn.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nome Fantasia:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(134, 97);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(477, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "CNPJ:";
            // 
            // TxtCNPJ
            // 
            this.TxtCNPJ.Location = new System.Drawing.Point(134, 152);
            this.TxtCNPJ.Mask = "99.999.999/9999-99";
            this.TxtCNPJ.Name = "TxtCNPJ";
            this.TxtCNPJ.Size = new System.Drawing.Size(179, 20);
            this.TxtCNPJ.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "PEÇA",
            "PNEU",
            "SUPRIMENTOS",
            "FERRAMENTAS"});
            this.comboBox1.Location = new System.Drawing.Point(134, 226);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Tipo de Produto:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 299);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Telefone:";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(134, 296);
            this.maskedTextBox1.Mask = "(99)99999-9999";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(121, 20);
            this.maskedTextBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(415, 227);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(216, 20);
            this.textBox2.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(357, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "E-mail:";
            // 
            // BtnSalvaFornecedor
            // 
            this.BtnSalvaFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalvaFornecedor.Location = new System.Drawing.Point(134, 399);
            this.BtnSalvaFornecedor.Name = "BtnSalvaFornecedor";
            this.BtnSalvaFornecedor.Size = new System.Drawing.Size(108, 43);
            this.BtnSalvaFornecedor.TabIndex = 10;
            this.BtnSalvaFornecedor.Text = "Salvar";
            this.BtnSalvaFornecedor.UseVisualStyleBackColor = true;
            // 
            // BtnAtualizaForn
            // 
            this.BtnAtualizaForn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAtualizaForn.Location = new System.Drawing.Point(305, 399);
            this.BtnAtualizaForn.Name = "BtnAtualizaForn";
            this.BtnAtualizaForn.Size = new System.Drawing.Size(108, 43);
            this.BtnAtualizaForn.TabIndex = 11;
            this.BtnAtualizaForn.Text = "Atualizar";
            this.BtnAtualizaForn.UseVisualStyleBackColor = true;
            // 
            // BtnExcluiForn
            // 
            this.BtnExcluiForn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExcluiForn.Location = new System.Drawing.Point(492, 399);
            this.BtnExcluiForn.Name = "BtnExcluiForn";
            this.BtnExcluiForn.Size = new System.Drawing.Size(108, 43);
            this.BtnExcluiForn.TabIndex = 12;
            this.BtnExcluiForn.Text = "Excluir";
            this.BtnExcluiForn.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "ID do Fornecedor:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(134, 41);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(74, 20);
            this.textBox3.TabIndex = 14;
            // 
            // Fornecedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 564);
            this.Controls.Add(this.BtnBuscaForn);
            this.Controls.Add(this.BtnCadastroForn);
            this.Controls.Add(this.PnlFornecedor);
            this.Controls.Add(this.label1);
            this.Name = "Fornecedores";
            this.Text = "Fornecedores";
            this.Load += new System.EventHandler(this.Fornecedores_Load);
            this.PnlFornecedor.ResumeLayout(false);
            this.PnlFornecedor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel PnlFornecedor;
        private System.Windows.Forms.Button BtnCadastroForn;
        private System.Windows.Forms.Button BtnBuscaForn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MaskedTextBox TxtCNPJ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BtnExcluiForn;
        private System.Windows.Forms.Button BtnAtualizaForn;
        private System.Windows.Forms.Button BtnSalvaFornecedor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
    }
}